const products = {
    crazy: {
        name: 'Crazy',
        price: 31000,
        img: 'images/products/burger-1.png',
        amount: 0,
        get totalSumm() {
            return this.price * this.amount;
        }
    },
    light: {
        name: 'Light',
        price: 26000,
        img: 'images/products/burger-2.png',
        amount: 0,
        get totalSumm() {
            return this.price * this.amount;
        }
    },
    cheeseburger: {
        name: 'CheeseBurger',
        price: 29000,
        img: 'images/products/burger-3.png',
        amount: 0,
        get totalSumm() {
            return this.price * this.amount;
        }
    },
    dburger: {
        name: 'dBurger',
        price: 24000,
        img: 'images/products/burger-4.png',
        amount: 0,
        get totalSumm() {
            return this.price * this.amount;
        }
    },
};


const wrapperListBtns = document.querySelectorAll('.wrapper__list-btn'),
    wrapperListCount = document.querySelector('.wrapper__list-count'),
    basketCount = document.querySelector('.warapper__navbar-count');


wrapperListBtns.forEach(btn => {
    btn.addEventListener('click', function () {
        plusOrMinus(btn);
    });
});

function plusOrMinus(btn) {
    //    closest - метод для получения родительского тега
    const parent = btn.closest('.wrapper__list-card'),
        parentId = parent.getAttribute('id');

    products[parentId].amount++;
    basket();
}
const basketList = document.querySelector('.wrapper__navbar-checklist');
const totalSumm = document.querySelector('.wrapper__navbar-totalprice');

function basket() {
    const allProducts = [];

    for (const key in products) {
        let totalCount = 0;
        const po = products[key];
        const productCard = document.querySelector(`#${po.name.toLowerCase()}`),
            parentIndicator = productCard.querySelector('.wrapper__list-count');

        if (po.amount) {
            parentIndicator.classList.add('active');
            parentIndicator.innerHTML = po.amount;
            totalCount += po.amount;
            allProducts.push(po);
        } else {
            parentIndicator.classList.remove('active');
            parentIndicator.innerHTML = 0;
        }
    }

    basketList.innerHTML = '';

    for (let i = 0; i < allProducts.length; i++) {
        basketList.innerHTML += cardItemBurger(allProducts[i]);
    }


    const totalProductsCount = productsTotalCount();

    if (totalProductsCount) {
        basketCount.classList.add('active');
    } else {
        basketCount.classList.remove('active');
    }
    basketCount.innerHTML = totalProductsCount.toString();
    totalSumm.innerHTML = productsTotalSumm();
}

function productsTotalCount() {
    let total = 0;
    for (const key in products) {
        total += products[key].amount;
    }
    return total;
}

function productsTotalSumm() {
    let total = 0;
    for (const key in products) {
        total += products[key].amount * products[key].price;
    }
    return total;
}


const wrapperNavBarBasket = document.querySelector('.wrapper__navbar-basket'),
    basketBtn = document.querySelector('.wrapper__navbar-btn'),
    basketCloseBtn = document.querySelector('.wrapper__navbar-close');


basketBtn.addEventListener('click', () => {
    wrapperNavBarBasket.classList.toggle('active');
});

basketCloseBtn.addEventListener('click', () => {
    wrapperNavBarBasket.classList.remove('active');
});




function cardItemBurger(productData) {
    return `
        <div class="wrapper__navbar-product">
           <div class="wrapper__navbar-info">
               <img src="${productData.img}" alt="" class="wrapper__navbar-productImage">
               <div class="wrapper__navbar-infoSub">
                  <p class="wrapper__navbar-infoName">${productData.name}</p>
                  <p class="wrapper__navbar-infoPrice">${productData.price}</p>
               </div>
           </div>
          <div class="wrapper__navbar-option" id="${productData.name.toLowerCase()}_card">
            <button class="wrapper__navbar-symbol fa-minus" data-symbol="-">-</button>
            <output class="wrapper__navbar-count">${productData.amount}</output>
            <button class="wrapper__navbar-symbol fa-plus" data-symbol="+">+</button>
          </div>
        </div>
    `;
}

window.addEventListener('click', (e) => {
    const btn = e.target;
    // contains - это метод для проверки на наличие символа/объекта в строке/массиве
    if (btn.classList.contains('wrapper__navbar-symbol')) {
        const attr = btn.getAttribute('data-symbol');
        const parent = btn.closest('.wrapper__navbar-option');

        if (parent) {
            const productId = parent.getAttribute('id').split('_')[0];
            if (attr == '-') {
                products[productId].amount--;
            } else if (attr == '+') {
                products[productId].amount++;
            }

            basket();
        }
    }
});


const printBody = document.querySelector('.print__body'),
    printFooter = document.querySelector('.print__footer'),
    wrapperNavBarBottom = document.querySelector('.wrapper__navbar-bottom');


wrapperNavBarBottom.addEventListener('click', () => {
    printBody.innerHTML = '';

    for (const key in products) {
        const po = products[key];
        if (po.amount) {
            printBody.innerHTML += `
              <p class="print__body-item-name">
                 <span class="name">${po.name}</span>
                 <span>-</span>
                 <span class="count">${po.amount}</span>
              </p>
              <p class="prinе__body-item_summ">${po.totalSumm}</p>
           `
        }
    }
    printFooter.innerHTML = `
    
    `;
    window.print();

});